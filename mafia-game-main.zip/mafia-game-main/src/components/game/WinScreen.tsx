import { alivePlayers } from "@/game/engine";
import { personaTrait } from "@/game/personas";
import { localizedRole, useI18n } from "@/i18n";
import type { GameState } from "@/game/types";
import { cn } from "@/lib/utils";
import {
  GhostButton,
  PrimaryButton,
  ScreenShell,
  SectionTitle,
  formatNights,
  formatSurvivors,
  logEntryText,
} from "./ui";

export default function WinScreen({
  game,
  onSamePlayers,
  onNewSetup,
  onMenu,
}: {
  game: GameState;
  onSamePlayers: () => void;
  onNewSetup: () => void;
  onMenu: () => void;
}) {
  const { t: tr } = useI18n();
  const jesterWin = game.winner === "jester";
  const mafiaWin = game.winner === "mafia";
  const alive = alivePlayers(game.players);
  // Only in AI mode is there a single human — friends mode is pass-and-play,
  // so the "you" badge must never appear there.
  const aiMode = game.playMode === "ai";

  return (
    <ScreenShell>
      <div className="text-center">
        <div
          className={
            jesterWin
              ? "animate-float text-8xl"
              : mafiaWin
                ? "animate-pulse-red text-8xl"
                : "animate-float text-8xl"
          }
        >
          {jesterWin ? "🎭" : mafiaWin ? "🔪" : "🏆"}
        </div>
        <p className="mt-4 text-sm font-extrabold text-muted-foreground">{tr("win.ended")}</p>
        <h1
          className={`mt-2 text-4xl font-black leading-tight ${
            jesterWin
              ? "text-glow text-purple-400"
              : mafiaWin
                ? "text-glow text-red-400"
                : "text-glow-gold text-accent"
          }`}
        >
          {jesterWin ? tr("win.jesterWon") : mafiaWin ? tr("win.mafiaWon") : tr("win.citizensWon")}
        </h1>
        <p className="mx-auto mt-3 max-w-[320px] text-sm leading-6 text-muted-foreground">
          {jesterWin
            ? tr("win.jesterDesc")
            : mafiaWin
              ? tr("win.mafiaDesc")
              : tr("win.citizensDesc")}
        </p>
      </div>

      <div className="rounded-2xl border border-white/10 bg-card/70 p-4 text-center">
        <p className="text-xs font-extrabold text-muted-foreground">
          {tr("win.lasted", { nights: formatNights(game.night) })}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          {tr("win.survived", { n: formatSurvivors(alive.length) })}
        </p>
      </div>

      <div className="flex flex-col gap-2.5">
        <SectionTitle>{tr("win.finalResults")}</SectionTitle>
        <div className="grid grid-cols-[1fr_auto_auto] items-center gap-x-3 rounded-xl border border-white/10 bg-card/40 px-4 py-1.5 text-[10px] font-extrabold text-muted-foreground">
          <span>{tr("win.playerCol")}</span>
          <span>{aiMode ? tr("win.roleColAi") : tr("win.roleCol")}</span>
          <span>{tr("win.resultCol")}</span>
        </div>
        <div className="flex flex-col gap-2">
          {game.players.map((p) => {
            const r = localizedRole(p.role);
            const dead = p.status === "dead";
            const trait = personaTrait(game.aiStates?.[p.id]?.personalityId ?? "smart");
            return (
              <div
                key={p.id}
                className={cn(
                  "grid grid-cols-[1fr_auto_auto] items-center gap-x-3 rounded-xl border border-white/10 bg-card/70 px-4 py-2.5",
                  dead && "opacity-60",
                )}
              >
                <span className="flex items-center gap-2 overflow-hidden">
                  <span className={`truncate text-sm font-bold ${dead ? "line-through" : ""}`}>
                    {p.name}
                  </span>
                </span>
                <span className="flex items-center justify-end gap-1.5">
                  {p.isAi ? (
                    <span className="rounded-md bg-white/5 px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                      {trait}
                    </span>
                  ) : aiMode ? (
                    <span className="rounded-md bg-white/5 px-2 py-0.5 text-[11px] font-bold text-accent">
                      {tr("win.you")}
                    </span>
                  ) : null}
                  <span
                    className="rounded-md px-2 py-0.5 text-[11px] font-extrabold"
                    style={{ color: r.color, background: r.soft }}
                  >
                    {r.name}
                  </span>
                </span>
                <span
                  className={cn(
                    "rounded-md px-2 py-0.5 text-[11px] font-extrabold",
                    dead ? "bg-white/5 text-muted-foreground" : "bg-emerald-500/10 text-emerald-400",
                  )}
                >
                  {dead ? tr("win.out") : tr("win.aliveShort")}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <details className="group rounded-xl border border-white/10 bg-card/70">
        <summary className="cursor-pointer list-none px-4 py-3 text-sm font-bold text-accent">
          {tr("day.logTitle")}
        </summary>
        <div className="flex flex-col gap-2 border-t border-white/10 px-4 py-3">
          {game.log.map((entry) => (
            <p key={entry.id} className="text-xs leading-5 text-muted-foreground">
              <span className="font-extrabold text-accent">
                {tr("common.nightX", { n: entry.night })} —{" "}
                {entry.phase === "night" ? tr("common.nightPhase") : tr("common.dayPhase")}:
              </span>{" "}
              {logEntryText(entry, game.players)}
            </p>
          ))}
        </div>
      </details>

      <div className="mt-2 flex flex-col gap-2">
        <PrimaryButton onClick={onSamePlayers}>{tr("win.replaySame")}</PrimaryButton>
        <GhostButton onClick={onNewSetup}>{tr("win.replayRandom")}</GhostButton>
        <GhostButton onClick={onMenu}>{tr("win.toMenu")}</GhostButton>
      </div>
    </ScreenShell>
  );
}