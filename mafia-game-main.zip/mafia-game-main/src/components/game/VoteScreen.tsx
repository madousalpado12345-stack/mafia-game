import { alivePlayers } from "@/game/engine";
import { useI18n } from "@/i18n";
import type { GameState, Player } from "@/game/types";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { GameTopBar, PassPhone, PrimaryButton, ScreenShell, SelectableList, type SelectItem } from "./ui";

export default function VoteScreen({
  game,
  voter,
  index,
  total,
  aiMode,
  onVote,
  onExit,
  onSave,
}: {
  game: GameState;
  voter: Player;
  index: number;
  total: number;
  /** In AI mode the human votes directly — no phone handoff. */
  aiMode?: boolean;
  /** Records the vote and moves to the next voter. */
  onVote: (targetId: string | null) => void;
  onExit: () => void;
  onSave: () => void;
}) {
  const { t: tr } = useI18n();
  const [phase, setPhase] = useState<"handoff" | "choose">(aiMode ? "choose" : "handoff");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const alive = alivePlayers(game.players);
  const revote = game.tiedCandidates !== null;

  // All candidates look identical — voting must never reveal anyone's role.
  const candidates: SelectItem[] = alive
    .filter((p) => p.id !== voter.id)
    .filter((p) => (revote ? (game.tiedCandidates ?? []).includes(p.id) : true))
    .map((p) => ({
      id: p.id,
      label: p.name,
    }));

  const canAbstain = game.settings.allowAbstain && !revote;

  return (
    <ScreenShell>
      <GameTopBar
        title={tr("vote.title", { x: index + 1, y: total })}
        onExit={onExit}
        onSave={onSave}
      />

      <p className="text-center text-xs font-extrabold text-muted-foreground">
        {aiMode
          ? tr("vote.yourVote")
          : tr("vote.voterXofY", { revote: revote ? tr("vote.revoteRound") : "", x: index + 1, y: total })}
      </p>

      {phase === "handoff" ? (
        <>
          <div className="flex-1" />
          <PassPhone
            name={voter.name}
            note={tr("vote.handoffNote")}
          />
          <div className="flex-1" />
          <PrimaryButton onClick={() => setPhase("choose")}>{tr("vote.startVoting")}</PrimaryButton>
        </>
      ) : (
        <>
          <div className="text-center">
            <h2 className="text-xl font-black">{tr("vote.chooseTarget")}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {aiMode ? tr("vote.selfHint") : tr("vote.voterSelfHint", { name: voter.name })}
            </p>
          </div>

          <SelectableList
            items={candidates}
            selectedId={selectedId}
            onSelect={setSelectedId}
            empty={tr("vote.empty")}
          />

          {canAbstain && (
            <button
              type="button"
              onClick={() => setSelectedId("__abstain__")}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-start transition-all",
                selectedId === "__abstain__"
                  ? "border-muted-foreground bg-muted"
                  : "border-white/10 bg-card/70 hover:border-white/25",
              )}
            >
              <span className="text-xl">🤷</span>
              <span className="flex-1 text-sm font-bold">{tr("vote.abstain")}</span>
              <span
                className={cn(
                  "size-4 rounded-full border-2",
                  selectedId === "__abstain__" ? "border-muted-foreground bg-muted-foreground" : "border-white/25",
                )}
              />
            </button>
          )}

          <div className="mt-2">
            <PrimaryButton
              disabled={selectedId === null}
              onClick={() => {
                onVote(selectedId === "__abstain__" ? null : selectedId);
                setSelectedId(null);
                setPhase("handoff");
              }}
            >
              {tr("vote.confirm")}
            </PrimaryButton>
          </div>
        </>
      )}
    </ScreenShell>
  );
}